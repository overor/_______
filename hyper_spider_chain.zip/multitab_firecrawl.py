
import asyncio
from playwright.async_api import async_playwright

async def run_multi_scraper(urls):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        contexts = [await browser.new_context() for _ in urls]
        pages = [await ctx.new_page() for ctx in contexts]
        results = []

        for i, page in enumerate(pages):
            await page.goto(urls[i])
            await page.wait_for_timeout(5000)
            items = await page.query_selector_all("div[class*=MenuItem]")
            for item in items:
                try:
                    name_el = await item.query_selector("h3")
                    price_el = await item.query_selector("span[class*=Price]")
                    name = await name_el.inner_text() if name_el else None
                    price = await price_el.inner_text() if price_el else None
                    if name and price:
                        results.append({
                            "name": name.strip(),
                            "price": price.strip(),
                            "source": urls[i]
                        })
                except:
                    continue
        await browser.close()
        return results

def scrape_multiple(urls):
    return asyncio.run(run_multi_scraper(urls))
