
import faiss
import numpy as np
import json
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')
index = faiss.IndexFlatL2(384)
metadata_store = []

def embed_and_store(items):
    global metadata_store
    texts = [f"{item['name']} {item['category']}" for item in items]
    embeddings = model.encode(texts)
    index.add(np.array(embeddings).astype('float32'))
    metadata_store.extend(items)

def search_similar(query, top_k=5):
    embedding = model.encode([query]).astype('float32')
    D, I = index.search(embedding, top_k)
    return [metadata_store[i] for i in I[0]]
