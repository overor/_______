
import whisper
import openai

openai.api_key = "YOUR_OPENAI_API_KEY"

def transcribe_voice(audio_path):
    model = whisper.load_model("base")
    result = model.transcribe(audio_path)
    return result['text']

def interpret_order(text_prompt):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant that extracts food order info from user input."},
            {"role": "user", "content": text_prompt}
        ],
        max_tokens=100
    )
    return response.choices[0].message['content']
