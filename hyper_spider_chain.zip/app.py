
from fastapi import FastAPI, UploadFile
from vector_db import embed_and_store, search_similar
from voice_to_order import transcribe_voice, interpret_order
from multitab_firecrawl import scrape_multiple
import json

app = FastAPI()

@app.post("/crawl_and_index")
async def crawl_and_index(urls: list[str]):
    items = scrape_multiple(urls)
    embed_and_store(items)
    return {"status": "crawled", "count": len(items)}

@app.post("/voice_order")
async def voice_order(audio: UploadFile):
    with open("/tmp/audio.mp3", "wb") as f:
        f.write(await audio.read())
    prompt = transcribe_voice("/tmp/audio.mp3")
    interpreted = interpret_order(prompt)
    matches = search_similar(interpreted)
    return {"prompt": prompt, "interpreted": interpreted, "matches": matches}
