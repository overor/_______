# Changelog

## 0.1.0
- Manifest schema + loader
- RPC pool with concurrency + failover
- DriftExecution client (direct on-chain, no gateway)
- HF router chat client
- CLI smoketest
