class ArchonSDKError(Exception):
    """Base error for archon_drift_sdk."""


class ManifestError(ArchonSDKError):
    """Raised when manifest validation or loading fails."""


class RpcError(ArchonSDKError):
    """Raised for RPC pool failures."""


class DriftError(ArchonSDKError):
    """Raised for Drift SDK execution issues."""
