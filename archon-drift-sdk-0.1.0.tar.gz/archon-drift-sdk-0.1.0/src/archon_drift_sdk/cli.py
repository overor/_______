from __future__ import annotations

import argparse
import asyncio
import json
import os
from typing import Any, Dict

from .manifest import PublicAPIManifest
from .rpc_pool import RpcPool
from .drift_execution import DriftExecution, DriftEnvConfig
from .hf_llm_client import HFRouterChat, HFRouterConfig


def _load_manifest(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


async def _cmd_smoketest(args: argparse.Namespace) -> int:
    manifest_obj = _load_manifest(args.manifest)
    m = PublicAPIManifest.load(manifest_obj)

    sol_url = str(m.endpoints.blockchain["solana"].url)
    pool = RpcPool([sol_url], max_retries=m.default_config.max_retries, base_retry_delay_ms=m.default_config.retry_delay)

    async def init_drift(rpc_url: str):
        ex = DriftExecution(
            DriftEnvConfig(
                rpc_url=rpc_url,
                drift_env=args.drift_env,
                sub_account_id=args.sub_account,
                perp_market_indexes=[int(x) for x in args.perp_markets.split(",")] if args.perp_markets else [],
                spot_market_indexes=[],
            ),
            keypair_env="SOLANA_PRIVATE_KEY",
        )
        await ex.initialize()
        return ex

    ex = await pool.call(init_drift)
    try:
        pos = ex.get_open_perp_positions()
        print(json.dumps({"ok": True, "positions": list(pos.keys())}, indent=2))
    finally:
        await ex.close()

    if args.llm:
        hf_url = str(m.endpoints.ai_and_llm["huggingface_inference_providers"].url)
        async with HFRouterChat(HFRouterConfig(base_url=hf_url)) as llm:
            out = await llm.chat(
                [
                    {"role": "system", "content": "You are a terse assistant."},
                    {"role": "user", "content": "Return JSON: {"ping":"pong"}"},
                ]
            )
            print(out)

    return 0


def main() -> None:
    p = argparse.ArgumentParser(prog="archon-drift-sdk", description="archon_drift_sdk CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    st = sub.add_parser("smoketest", help="Initialize Drift and print open perp positions")
    st.add_argument("--manifest", required=True, help="Path to public-api-config JSON")
    st.add_argument("--drift-env", default="mainnet", choices=["mainnet", "devnet"])
    st.add_argument("--sub-account", type=int, default=0)
    st.add_argument("--perp-markets", default="0,1")
    st.add_argument("--llm", action="store_true", help="Also test HF router chat (requires HF_TOKEN)")

    args = p.parse_args()
    if args.cmd == "smoketest":
        raise SystemExit(asyncio.run(_cmd_smoketest(args)))


if __name__ == "__main__":
    main()
