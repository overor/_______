from __future__ import annotations

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field, HttpUrl

from .exceptions import ManifestError


class EndpointBase(BaseModel):
    url: Optional[HttpUrl] = None
    type: str
    description: Optional[str] = None
    rate_limit_note: Optional[str] = None
    access_note: Optional[str] = None
    network: Optional[str] = None
    compatibility: Optional[str] = None
    version: Optional[str] = None
    base_url: Optional[HttpUrl] = None
    endpoints: Optional[Dict[str, str]] = None
    key_features: Optional[list[str]] = None


class EndpointsBlock(BaseModel):
    blockchain: Dict[str, EndpointBase]
    research: Optional[Dict[str, EndpointBase]] = None
    ai_and_llm: Optional[Dict[str, EndpointBase]] = None
    developer_platforms: Optional[Dict[str, EndpointBase]] = None


class DefaultConfig(BaseModel):
    timeout: int = Field(..., ge=1)         # ms
    max_retries: int = Field(..., ge=0)
    retry_delay: int = Field(..., ge=0)     # ms
    user_agent: str


class PublicAPIManifest(BaseModel):
    name: str
    version: str
    description: Optional[str] = None
    endpoints: EndpointsBlock
    usage_notes: Dict[str, str] = Field(default_factory=dict)
    default_config: DefaultConfig

    @staticmethod
    def load(obj: Dict[str, Any]) -> "PublicAPIManifest":
        try:
            return PublicAPIManifest.model_validate(obj)
        except Exception as e:
            raise ManifestError(str(e)) from e
