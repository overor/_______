"""archon_drift_sdk

Production-grade utilities for:
- public-endpoint manifest ingestion
- Solana RPC pool with rate-limit aware failover
- Drift Protocol SDK execution (direct on-chain)
- HuggingFace router (OpenAI-compatible) chat client
"""

from .manifest import PublicAPIManifest
from .rpc_pool import RpcPool
from .drift_execution import DriftExecution, DriftEnvConfig
from .hf_llm_client import HFRouterChat, HFRouterConfig

__all__ = [
    "PublicAPIManifest",
    "RpcPool",
    "DriftExecution",
    "DriftEnvConfig",
    "HFRouterChat",
    "HFRouterConfig",
]
