import asyncio
import pytest
from archon_drift_sdk import RpcPool

@pytest.mark.asyncio
async def test_rpc_pool_basic():
    pool = RpcPool(["http://example.invalid"], max_retries=1, base_retry_delay_ms=1)

    async def fn(url: str):
        raise RuntimeError("fail")

    with pytest.raises(Exception):
        await pool.call(fn)
