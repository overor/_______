from archon_drift_sdk import PublicAPIManifest

def test_manifest_load_minimal():
    obj = {
        "name": "x",
        "version": "0.0.1",
        "endpoints": {"blockchain": {"solana": {"url": "https://api.mainnet-beta.solana.com", "type": "JSON-RPC"}}},
        "usage_notes": {},
        "default_config": {"timeout": 30000, "max_retries": 3, "retry_delay": 1000, "user_agent": "x"},
    }
    m = PublicAPIManifest.load(obj)
    assert m.endpoints.blockchain["solana"].type == "JSON-RPC"
