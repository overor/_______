# archon-drift-sdk

Pip-installable SDK providing:

- **Public API manifest ingestion** (Pydantic)
- **Rate-limit aware Solana RPC pool** (bounded concurrency + failover)
- **Direct on-chain Drift execution** (no gateway)
- **HuggingFace router chat client** (OpenAI-compatible)

## Install

```bash
pip install archon-drift-sdk
```

## Environment

- `SOLANA_PRIVATE_KEY` : base58-encoded secret key, OR JSON 64-byte array string
- `HF_TOKEN` : HuggingFace token (only if using HF router)

## CLI smoketest

```bash
archon-drift-sdk smoketest --manifest ./public-api-config.json --drift-env mainnet --llm
```

## Python usage (Drift)

```python
import asyncio
from archon_drift_sdk import DriftExecution, DriftEnvConfig

async def run():
    ex = DriftExecution(DriftEnvConfig(rpc_url="https://api.mainnet-beta.solana.com", perp_market_indexes=[0,1]))
    await ex.initialize()
    print(ex.get_open_perp_positions().keys())
    await ex.close()

asyncio.run(run())
```
