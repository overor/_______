"use client"

import { useState, useEffect } from "react"
import { ArrowUpDown, TrendingUp, Wallet, Sparkles, Zap } from "lucide-react"

interface Token {
  address: string
  symbol: string
  name: string
  decimals: number
  logoURI?: string
}

const POPULAR_TOKENS: Token[] = [
  { address: "So11111111111111111111111111111111111111112", symbol: "SOL", name: "Solana", decimals: 9 },
  { address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", symbol: "USDC", name: "USD Coin", decimals: 6 },
  { address: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB", symbol: "USDT", name: "Tether", decimals: 6 },
  { address: "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So", symbol: "mSOL", name: "Marinade SOL", decimals: 9 },
]

export function TasterDex() {
  const [isProfiting, setIsProfiting] = useState(false)
  const [moneyEmojis, setMoneyEmojis] = useState<{ id: number; left: string }[]>([])
  const [fromToken, setFromToken] = useState(POPULAR_TOKENS[0])
  const [toToken, setToToken] = useState(POPULAR_TOKENS[1])
  const [fromAmount, setFromAmount] = useState("")
  const [toAmount, setToAmount] = useState("")
  const [isLoadingQuote, setIsLoadingQuote] = useState(false)
  const [walletConnected, setWalletConnected] = useState(false)

  useEffect(() => {
    const fetchQuote = async () => {
      if (!fromAmount || Number.parseFloat(fromAmount) <= 0) {
        setToAmount("")
        return
      }

      setIsLoadingQuote(true)
      try {
        const inputAmount = Math.floor(Number.parseFloat(fromAmount) * Math.pow(10, fromToken.decimals))

        const response = await fetch(
          `https://quote-api.jup.ag/v6/quote?inputMint=${fromToken.address}&outputMint=${toToken.address}&amount=${inputAmount}&slippageBps=50`,
        )

        if (response.ok) {
          const data = await response.json()
          const outAmount = data.outAmount / Math.pow(10, toToken.decimals)
          setToAmount(outAmount.toFixed(6))
          console.log("[v0] Jupiter quote fetched:", data)
        }
      } catch (error) {
        console.error("[v0] Failed to fetch Jupiter quote:", error)
      } finally {
        setIsLoadingQuote(false)
      }
    }

    const debounce = setTimeout(fetchQuote, 500)
    return () => clearTimeout(debounce)
  }, [fromAmount, fromToken, toToken])

  const handleProfit = () => {
    setIsProfiting(true)

    const newEmojis = Array.from({ length: 20 }, (_, i) => ({
      id: Date.now() + i,
      left: `${Math.random() * 100}%`,
    }))
    setMoneyEmojis(newEmojis)

    setTimeout(() => {
      setIsProfiting(false)
      setMoneyEmojis([])
    }, 3000)
  }

  const swapTokens = () => {
    setFromToken(toToken)
    setToToken(fromToken)
    setFromAmount(toAmount)
    setToAmount("")
  }

  const connectWallet = () => {
    setWalletConnected(true)
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-background via-muted/30 to-secondary/20 relative overflow-hidden">
      {moneyEmojis.map((emoji) => (
        <div
          key={emoji.id}
          className="absolute text-4xl animate-money-rain pointer-events-none"
          style={{ left: emoji.left, top: "-50px" }}
        >
          💰
        </div>
      ))}

      <div className="absolute top-20 left-10 w-32 h-32 bg-primary/10 rounded-full blur-3xl animate-float" />
      <div
        className="absolute bottom-20 right-10 w-40 h-40 bg-accent/10 rounded-full blur-3xl animate-float"
        style={{ animationDelay: "1s" }}
      />
      <div
        className="absolute top-1/2 left-1/4 w-24 h-24 bg-secondary/10 rounded-full blur-3xl animate-float"
        style={{ animationDelay: "2s" }}
      />

      <header className="absolute top-0 left-0 right-0 p-6 flex items-center justify-between max-w-7xl mx-auto w-full z-10">
        <div className="flex items-center gap-3">
          <div className="relative w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
            <Sparkles className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-black bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            Taster
          </h1>
        </div>
        <button
          onClick={connectWallet}
          className={`px-6 py-3 rounded-full font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center gap-2 ${
            walletConnected
              ? "bg-gradient-to-r from-primary/80 to-primary text-primary-foreground"
              : "bg-gradient-to-r from-secondary/80 to-secondary text-secondary-foreground"
          }`}
        >
          <Wallet className="w-5 h-5" />
          {walletConnected ? "Connected" : "Connect"}
        </button>
      </header>

      <main className="flex flex-col items-center gap-8 max-w-md w-full relative z-10">
        <div className="text-center space-y-2">
          <h2 className="text-4xl font-black text-foreground leading-tight text-balance">Trade. Earn. Repeat.</h2>
          <p className="text-lg text-muted-foreground">Powered by Jupiter on Solana</p>
        </div>

        <div className="w-full p-6 rounded-[2rem] bg-card shadow-[0_8px_30px_rgb(0,0,0,0.12)] border-4 border-white/50">
          <div className="space-y-4">
            <div className="p-5 rounded-3xl bg-gradient-to-br from-muted/50 to-muted/30 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-muted-foreground uppercase tracking-wide">You Pay</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <input
                  type="text"
                  placeholder="0.0"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  className="text-3xl font-black bg-transparent outline-none w-full text-foreground placeholder:text-muted-foreground/30"
                />
                <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-br from-primary to-primary/80 shadow-lg shrink-0">
                  <div className="w-6 h-6 rounded-full bg-white/90 flex items-center justify-center text-xs font-black">
                    {fromToken.symbol[0]}
                  </div>
                  <span className="font-black text-primary-foreground">{fromToken.symbol}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-center -my-2 relative z-10">
              <button
                onClick={swapTokens}
                className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-accent/80 shadow-lg hover:shadow-xl hover:scale-110 hover:rotate-180 transition-all duration-500 flex items-center justify-center text-accent-foreground"
              >
                <ArrowUpDown className="w-6 h-6" />
              </button>
            </div>

            <div className="p-5 rounded-3xl bg-gradient-to-br from-muted/50 to-muted/30 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-muted-foreground uppercase tracking-wide">You Get</span>
                {isLoadingQuote && <span className="text-xs text-accent animate-pulse">Fetching quote...</span>}
              </div>
              <div className="flex items-center justify-between gap-4">
                <input
                  type="text"
                  placeholder="0.0"
                  value={toAmount}
                  readOnly
                  className="text-3xl font-black bg-transparent outline-none w-full text-foreground placeholder:text-muted-foreground/30"
                />
                <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-br from-chart-5 to-chart-5/80 shadow-lg shrink-0">
                  <div className="w-6 h-6 rounded-full bg-white/90 flex items-center justify-center text-xs font-black">
                    {toToken.symbol[0]}
                  </div>
                  <span className="font-black text-white">{toToken.symbol}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={handleProfit}
          disabled={isProfiting || !walletConnected || !fromAmount}
          className={`group relative px-20 py-8 rounded-[2rem] font-black text-4xl shadow-2xl transition-all duration-500 disabled:opacity-90 border-4 ${
            isProfiting
              ? "bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%] animate-[gradient_2s_linear_infinite] text-primary-foreground border-white scale-110 animate-pulse-glow"
              : "bg-gradient-to-br from-primary to-accent text-primary-foreground hover:scale-105 hover:shadow-[0_0_50px_rgba(34,197,94,0.5)] border-white/50"
          }`}
        >
          {isProfiting ? (
            <span className="flex items-center gap-3">
              <Zap className="w-8 h-8 animate-bounce" />
              PROFIT!
              <Zap className="w-8 h-8 animate-bounce" />
            </span>
          ) : (
            <span className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 group-hover:rotate-12 transition-transform" />
              PROFIT
            </span>
          )}
        </button>

        <div className="grid grid-cols-3 gap-3 w-full mt-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-chart-1/20 to-chart-1/10 backdrop-blur-sm border-2 border-chart-1/20 text-center">
            <div className="text-xl font-black text-primary">$24B</div>
            <div className="text-xs text-muted-foreground font-bold">Volume</div>
          </div>
          <div className="p-4 rounded-2xl bg-gradient-to-br from-chart-2/20 to-chart-2/10 backdrop-blur-sm border-2 border-chart-2/20 text-center">
            <div className="text-xl font-black text-accent">42K</div>
            <div className="text-xs text-muted-foreground font-bold">Traders</div>
          </div>
          <div className="p-4 rounded-2xl bg-gradient-to-br from-chart-3/20 to-chart-3/10 backdrop-blur-sm border-2 border-chart-3/20 text-center">
            <div className="text-xl font-black text-secondary">0.3%</div>
            <div className="text-xs text-muted-foreground font-bold">Fee</div>
          </div>
        </div>
      </main>

      <footer className="absolute bottom-6 text-center text-sm text-muted-foreground font-medium z-10">
        <p>Not financial advice. DYOR. 🚀</p>
      </footer>
    </div>
  )
}
