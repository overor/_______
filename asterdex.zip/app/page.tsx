import { TasterDex } from "@/components/taster-dex"

export default function Home() {
  return <TasterDex />
}
