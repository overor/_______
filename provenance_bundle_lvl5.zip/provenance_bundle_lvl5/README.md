# Provenance + Attestation Bundle (Level 5)

This bundle turns your chat transcript into court-friendly, liquidity-ready collateral with proofs and an EIP-712 attestation pipeline.

## Contents
- `transcript.txt` — the ingested transcript (source: /mnt/data/text.txt)
- `ledger.jsonl` — per-line SHA-256 + running hash-chain
- `merkle.json` — merkle levels + root over all message hashes
- `receipts/entry_*.json` — inclusion proofs per line
- `roots.txt` — chain_tip and merkle_root
- `contracts/AssetRegistryMonolithV2.sol` — single-file registry with EIP-712 verify
- `scripts/sign_hap.ts` — ethers v6 tool to compute assetId and sign typed-data
- `scripts/register_asset.sh` — Foundry `cast` template for on-chain registration
- `scripts/verify.py` — offline integrity verifier
- `typed_data/hap_attestation_typed_data.json` — ready-to-sign typed-data (fill assetId/fileHash)
- `docs/burrocradi_consolidated.pdf` — human-readable affidavit & instructions

## Generate or update artifacts
1. Verify integrity offline:

   ```bash
   python3 scripts/verify.py
   ```

2. Compute file hash (SHA-256) of the PDF:

   ```bash
   shasum -a 256 docs/burrocradi_consolidated.pdf
   # copy 64-hex to FILE_HASH for register_asset.sh
   ```

3. Compute assetId + sign EIP-712:

   ```bash
   # npm i ethers@6
   node scripts/sign_hap.ts --pk <HEX_PRIVKEY> --subject <ADDR> --verifying <REGISTRY> --chain 1      --fileHash 0x... --merkleRoot 0x7b01356cc2e7cfd4740b4231a4426d675500ced795b6b508311c7651ac587722 --chainTip 0xa25c7c7a2149bc25c4db337c48d40ea0f974507b940e43521d062964df945922 --fp 9500 --sb 10500      --start $(date -u +%s) --end $(( $(date -u +%s) + 604800 ))
   ```

   The tool updates `typed_data/hap_attestation_typed_data.json` with `assetId` and `signature`.

4. Register on-chain (Foundry):

   ```bash
   export RPC_URL=<https endpoint>
   export PRIVATE_KEY=<hex>
   ./scripts/register_asset.sh
   ```

### AssetId definition
`assetId = keccak256( fileHash || merkleRoot || chainTip )` (all as 32-byte concatenation).
`sign_hap.ts` computes this deterministically.

---

Security: single-file contract avoids hidden imports; ECDSA malleability checks included; registry supports freeze after registration.
