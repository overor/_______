// sign_hap.ts (ethers v6)
// Usage: node sign_hap.js --pk <hex> --subject <addr> --verifying <addr> --chain 1 \
//        --fileHash 0x.. --merkleRoot 0x.. --chainTip 0x.. --fp 9500 --sb 10500 --start <unix> --end <unix>
import { Wallet, keccak256, concat, getBytes, toUtf8Bytes } from "ethers";
import fs from "fs";

function hexToBytes32(h: string): string {
  if (!h.startsWith("0x") || h.length !== 66) throw new Error("bytes32 required");
  return h.toLowerCase();
}

function concatBytes32(a: string, b: string, c: string): string {
  const ab = concat([getBytes(a), getBytes(b), getBytes(c)]);
  return keccak256(ab);
}

function loadTyped(file: string) {
  return JSON.parse(fs.readFileSync(file, "utf-8"));
}

function saveTyped(file: string, obj: any) {
  fs.writeFileSync(file, JSON.stringify(obj, null, 2));
}

async function main() {
  const args = Object.fromEntries(process.argv.slice(2).map((x, i, arr) => {
    if (x.startsWith("--")) return [x.slice(2), arr[i+1]];
    return [];
  }).filter(Boolean) as any);

  const pk = args.pk;
  const subject = args.subject;
  const verifying = args.verifying || "0x0000000000000000000000000000000000000000";
  const chainId = parseInt(args.chain || "1", 10);
  const fileHash = hexToBytes32(args.fileHash);
  const merkleRoot = hexToBytes32(args.merkleRoot);
  const chainTip = hexToBytes32(args.chainTip);
  const fp = parseInt(args.fp || "9500", 10);
  const sb = parseInt(args.sb || "10500", 10);
  const start = parseInt(args.start, 10);
  const end = parseInt(args.end, 10);
  const typedPath = args.typed || "typed_data/hap_attestation_typed_data.json";

  const assetId = concatBytes32(fileHash, merkleRoot, chainTip);

  const wallet = new Wallet(pk);

  const typed = loadTyped(typedPath);
  typed.domain.chainId = chainId;
  typed.domain.verifyingContract = verifying;
  typed.message.subject = subject;
  typed.message.assetId = assetId;
  typed.message.fileHash = fileHash;
  typed.message.merkleRoot = merkleRoot;
  typed.message.chainTip = chainTip;

  // Wallet._signTypedData(domain, types, message) (ethers v6)
  const signature = await wallet.signTypedData(typed.domain, typed.types as any, typed.message);
  saveTyped(typedPath, { ...typed, signature });

  console.log("assetId:", assetId);
  console.log("signature:", signature);
}

main().catch((e) => { console.error(e); process.exit(1); });
