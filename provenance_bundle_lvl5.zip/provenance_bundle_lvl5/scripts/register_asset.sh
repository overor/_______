#!/usr/bin/env bash
# register_asset.sh - Foundry cast template
# Prereqs: cast (Foundry), RPC_URL, PRIVATE_KEY env vars set

ASSET_ID="{ASSET_ID}"                   # fill with output from sign_hap.ts
REGISTRY="{REGISTRY_ADDRESS}"           # deployed AssetRegistryMonolithV2
FILE_HASH="{FILE_HASH}"                 # sha256 of PDF (below)
MERKLE_ROOT="0x7b01356cc2e7cfd4740b4231a4426d675500ced795b6b508311c7651ac587722"
CHAIN_TIP="0xa25c7c7a2149bc25c4db337c48d40ea0f974507b940e43521d062964df945922"
URI="ipfs://{CID_OR_URL}"

cast send "$REGISTRY"   "registerAsset(bytes32,bytes32,bytes32,bytes32,string)"   "$ASSET_ID" "$FILE_HASH" "$MERKLE_ROOT" "$CHAIN_TIP" "$URI"
