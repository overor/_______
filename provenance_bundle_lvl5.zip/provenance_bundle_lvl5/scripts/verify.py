#!/usr/bin/env python3
import json, hashlib, os, sys

BUNDLE = os.path.dirname(__file__) or "."
ledger_path = os.path.join(BUNDLE, "ledger.jsonl")
merkle_path = os.path.join(BUNDLE, "merkle.json")

def main():
    # Verify hash-chain
    prev = bytes([0])*32
    with open(ledger_path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            row = json.loads(line)
            msg_sha = bytes.fromhex(row["msg_sha"][2:])
            expect_prev = row["prev_chain"]
            chain = hashlib.sha256(prev + msg_sha).digest()
            if "0x"+prev.hex() != expect_prev:
                print(f"ERR chain prev mismatch at {i}")
                sys.exit(1)
            if "0x"+chain.hex() != row["chain_hash"]:
                print(f"ERR chain hash mismatch at {i}")
                sys.exit(1)
            prev = chain
    print("OK: hash-chain verified. chain_tip =", "0x"+prev.hex())

    # Verify merkle root recomputation
    with open(merkle_path, "r") as f:
        m = json.load(f)
    leaves = [bytes.fromhex(h[2:]) for h in m["levels"][0]]
    # reconstruct parents up to root
    cur = leaves
    while len(cur) > 1:
        nxt = []
        for i in range(0, len(cur), 2):
            a = cur[i]
            b = cur[i+1] if i+1 < len(cur) else cur[i]
            nxt.append(hashlib.sha256(a+b).digest())
        cur = nxt
    root = "0x"+cur[0].hex() if cur else "0x"+hashlib.sha256(b"").hexdigest()
    assert root == m["root"], "ERR merkle root mismatch"
    print("OK: merkle root verified.", root)

if __name__ == "__main__":
    main()
