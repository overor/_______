
from fastapi import FastAPI, Request
from pydantic import BaseModel
from crewai import Crew, Agent, Task, Tool
import json
import firecrawl

app = FastAPI()

class CrawlRequest(BaseModel):
    url: str

# Tool Definitions
def firecrawl_tool(input_url):
    data = firecrawl.scrape_menu(input_url)
    return json.dumps(data)

firecrawl_tool_obj = Tool(name="FireCrawl", func=firecrawl_tool, description="Scrapes food menu from target URL")

# Agents
scraper_agent = Agent(
    role="Scraper Agent",
    goal="Extract menu and prices from food ordering sites",
    backstory="Expert crawler bot that scrapes menus.",
    tools=[firecrawl_tool_obj]
)

normalizer_agent = Agent(
    role="Normalizer",
    goal="Normalize scraped data into structured menu format",
    backstory="GPT agent that cleans scraped data",
    tools=[]
)

@app.post("/crawl")
async def crawl_and_process(request: CrawlRequest):
    url = request.url

    # Define Crew Task
    task1 = Task(
        description=f"Use FireCrawl to extract the menu from {url}",
        expected_output="JSON list of items with name and price",
        agent=scraper_agent
    )

    task2 = Task(
        description="Normalize the raw scraped menu using best practices (names, categories, prices as float)",
        expected_output="Clean JSON format",
        agent=normalizer_agent
    )

    crew = Crew(
        agents=[scraper_agent, normalizer_agent],
        tasks=[task1, task2]
    )

    result = crew.run()
    return {"result": result}
