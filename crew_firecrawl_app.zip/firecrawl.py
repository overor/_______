
import asyncio
from playwright.async_api import async_playwright

async def run_scraper(url):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        await page.goto(url, timeout=60000)
        await page.wait_for_timeout(5000)  # Wait for JS rendering

        items = await page.query_selector_all("div[class*=MenuItem]")
        results = []

        for item in items:
            try:
                name_el = await item.query_selector("h3")
                price_el = await item.query_selector("span[class*=Price]")

                name = await name_el.inner_text() if name_el else None
                price = await price_el.inner_text() if price_el else None

                if name and price:
                    results.append({
                        "name": name.strip(),
                        "price": price.strip()
                    })
            except:
                continue

        await browser.close()
        return results

def scrape_menu(url):
    return asyncio.run(run_scraper(url))
