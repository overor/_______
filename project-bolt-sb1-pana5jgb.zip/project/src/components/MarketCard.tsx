import React, { useMemo } from 'react';
import { MarketState } from '../types/market';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MarketCardProps {
  market: MarketState;
  priceChange?: number;
}

export const MarketCard: React.FC<MarketCardProps> = ({ market, priceChange = 0 }) => {
  const venueColorMap = {
    CB: 'from-blue-50 to-blue-100',
    BN: 'from-amber-50 to-amber-100',
    DY: 'from-violet-50 to-violet-100',
  };

  const venueBadgeMap = {
    CB: 'bg-blue-100 text-blue-700 border-blue-300',
    BN: 'bg-amber-100 text-amber-700 border-amber-300',
    DY: 'bg-violet-100 text-violet-700 border-violet-300',
  };

  const spreadIntensity = Math.min(market.spread / 2, 1);
  const volIntensity = Math.min(market.volume / 0.001, 1);

  const hasSignals = market.spread < 1.5 || market.volume > 0.0002;

  const priceChangeColor = priceChange > 0 ? 'text-emerald-600' : priceChange < 0 ? 'text-red-600' : 'text-slate-600';

  return (
    <div
      className={`
        relative overflow-hidden rounded-2xl p-5 transition-all duration-300
        bg-gradient-to-br ${venueColorMap[market.venue]}
        border border-slate-300 shadow-lg hover:shadow-xl
        ${market.isStale ? 'opacity-60' : 'opacity-100'}
      `}
    >
      <div className="absolute inset-0 pointer-events-none">
        {hasSignals && (
          <div
            className="absolute inset-0 opacity-10 bg-gradient-to-tr from-emerald-300"
            style={{ animation: 'pulse 2s infinite' }}
          />
        )}
      </div>

      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="text-xl font-bold text-slate-900 tracking-tight">{market.symbol}</div>
            <div className={`text-xs font-bold tracking-widest mt-1 px-2 py-1 rounded border ${venueBadgeMap[market.venue]}`}>
              {market.venue === 'CB' && 'Coinbase'}
              {market.venue === 'BN' && 'Binance'}
              {market.venue === 'DY' && 'dYdX'}
            </div>
          </div>
          {priceChange !== 0 && (
            <div className={`flex items-center gap-1 ${priceChangeColor}`}>
              {priceChange > 0 ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
            </div>
          )}
        </div>

        <div className="mb-5">
          <div className="text-4xl font-bold text-slate-900 font-mono tracking-tight">
            ${market.price.toFixed(2)}
          </div>
          {priceChange !== 0 && (
            <div className={`text-sm font-mono font-semibold mt-1 ${priceChangeColor}`}>
              {priceChange > 0 ? '+' : ''}{(priceChange * 100).toFixed(3)}%
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4 pb-4 border-t border-slate-300/50">
          <div className="mt-4">
            <div className="text-xs font-bold text-slate-600 uppercase tracking-widest mb-1">
              Bid
            </div>
            <div className="text-lg font-bold font-mono text-emerald-700">
              ${market.bid.toFixed(2)}
            </div>
          </div>
          <div className="mt-4">
            <div className="text-xs font-bold text-slate-600 uppercase tracking-widest mb-1">
              Ask
            </div>
            <div className="text-lg font-bold font-mono text-red-700">
              ${market.ask.toFixed(2)}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">
                Spread: {market.spread.toFixed(1)} bps
              </span>
            </div>
            <div className="h-2 rounded-full bg-white/40 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600 rounded-full transition-all duration-300"
                style={{ width: `${Math.max(Math.min(spreadIntensity * 100, 100), 5)}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">
                Volume: {(market.volume * 100).toFixed(2)}%
              </span>
            </div>
            <div className="h-2 rounded-full bg-white/40 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all duration-300"
                style={{ width: `${Math.max(Math.min(volIntensity * 100, 100), 5)}%` }}
              />
            </div>
          </div>
        </div>

        {market.isStale && (
          <div className="mt-4 px-3 py-2 rounded-lg bg-yellow-100 border border-yellow-300">
            <span className="text-xs font-semibold text-yellow-800">Data stale</span>
          </div>
        )}
      </div>
    </div>
  );
};
