import React from 'react';
import { Download, Trash2 } from 'lucide-react';

interface FooterProps {
  onExport: () => void;
  onClear: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onExport, onClear }) => {
  return (
    <footer className="h-14 bg-gradient-to-t from-slate-50 to-slate-100 border-t border-slate-200 shadow-sm flex items-center px-6 gap-4">
      <button
        onClick={onExport}
        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-blue-50 hover:border-blue-400 hover:text-blue-700 transition-all duration-200 shadow-sm"
      >
        <Download size={16} />
        Export
      </button>
      <button
        onClick={onClear}
        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-red-50 hover:border-red-400 hover:text-red-700 transition-all duration-200 shadow-sm"
      >
        <Trash2 size={16} />
        Clear
      </button>
      <div className="flex-1" />
      <span className="text-xs font-mono text-slate-500">
        Built for high-frequency trading • Real-time aggregation
      </span>
    </footer>
  );
};
