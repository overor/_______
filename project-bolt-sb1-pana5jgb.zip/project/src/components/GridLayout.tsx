import React from 'react';
import { Market } from '../services/market';
import { MarketCard } from './MarketCard';

interface GridLayoutProps {
  markets: ReadonlyMap<string, Market>;
  priceHistory: Map<string, number>;
}

export const GridLayout: React.FC<GridLayoutProps> = ({ markets, priceHistory }) => {
  const marketArray = Array.from(markets.entries()).map(([key, market]) => ({
    key,
    market,
    priceChange: priceHistory.get(key) || 0,
  }));

  const symbols = new Map<string, typeof marketArray>();
  marketArray.forEach((item) => {
    const state = item.market.getState();
    if (!symbols.has(state.symbol)) {
      symbols.set(state.symbol, []);
    }
    symbols.get(state.symbol)!.push(item);
  });

  return (
    <main className="flex-1 overflow-y-auto px-6 py-6">
      <div className="space-y-8">
        {Array.from(symbols.entries()).map(([symbol, items]) => (
          <div key={symbol}>
            <div className="mb-3 pb-2 border-b-2 border-slate-300">
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">{symbol}</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {items.map((item) => (
                <MarketCard
                  key={item.key}
                  market={item.market.getState()}
                  priceChange={item.priceChange}
                />
              ))}
            </div>
          </div>
        ))}

        {marketArray.length === 0 && (
          <div className="flex items-center justify-center h-96 text-slate-500">
            <div className="text-center">
              <div className="text-6xl mb-4">⏳</div>
              <div className="font-semibold">Connecting to exchanges...</div>
              <div className="text-sm text-slate-400">Markets will appear here</div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};
