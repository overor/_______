import React from 'react';
import { EngineStats } from '../types/market';

interface HeaderProps {
  stats: EngineStats;
  isLive: boolean;
}

export const Header: React.FC<HeaderProps> = ({ stats, isLive }) => {
  return (
    <header className="h-16 bg-gradient-to-b from-slate-50 to-slate-100 border-b border-slate-200 shadow-sm flex items-center px-6 justify-between">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="text-2xl font-black tracking-tight">
            POLY<span className="text-blue-500">VENUE</span>
          </div>
          <div
            className={`px-3 py-1 rounded-lg text-xs font-bold tracking-wider transition-all duration-300 ${
              isLive
                ? 'bg-emerald-100 text-emerald-700 border border-emerald-300 shadow-md'
                : 'bg-red-100 text-red-700 border border-red-300'
            }`}
          >
            {isLive ? '● LIVE' : '○ CONNECTING'}
          </div>
        </div>

        <div className="flex gap-6 text-sm font-mono">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 backdrop-blur-sm border border-slate-200 shadow-sm">
            <span className="text-slate-500">RX:</span>
            <span className="text-slate-900 font-bold">{stats.rx}</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 backdrop-blur-sm border border-slate-200 shadow-sm">
            <span className="text-slate-500">ERR:</span>
            <span className={`font-bold ${stats.err > 0 ? 'text-red-600' : 'text-slate-900'}`}>
              {stats.err}
            </span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 backdrop-blur-sm border border-slate-200 shadow-sm">
            <span className="text-slate-500">VENUES:</span>
            <span className="text-slate-900 font-bold">{stats.venues}/3</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 backdrop-blur-sm border border-slate-200 shadow-sm font-mono text-sm">
        <span className="text-slate-500">LATENCY:</span>
        <span className="text-slate-900 font-bold">{stats.latency}ms</span>
      </div>
    </header>
  );
};
