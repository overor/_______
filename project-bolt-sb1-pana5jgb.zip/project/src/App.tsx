import React, { useEffect, useState, useRef } from 'react';
import { Engine } from './services/engine';
import { EngineStats } from './types/market';
import { Market } from './services/market';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { GridLayout } from './components/GridLayout';

export default function App() {
  const engineRef = useRef<Engine | null>(null);
  const [stats, setStats] = useState<EngineStats>({
    rx: 0,
    err: 0,
    venues: 0,
    latency: 0,
  });
  const [markets, setMarkets] = useState<ReadonlyMap<string, Market>>(new Map());
  const [priceHistory, setPriceHistory] = useState<Map<string, number>>(new Map());
  const renderStartRef = useRef<number>(0);

  useEffect(() => {
    const engine = new Engine();
    engineRef.current = engine;

    const unsubscribe = engine.subscribe((newStats) => {
      const renderTime = Date.now();
      if (renderStartRef.current > 0) {
        const latency = renderTime - renderStartRef.current;
        setStats({ ...newStats, latency: Math.round(latency) });
      }
      renderStartRef.current = renderTime;

      setMarkets(engine.getMarkets());

      const history = new Map<string, number>();
      engine.getMarkets().forEach((market, key) => {
        const state = market.getState();
        if (state.priceHistory.length >= 2) {
          const prev = state.priceHistory[state.priceHistory.length - 2];
          const current = state.priceHistory[state.priceHistory.length - 1];
          history.set(key, (current - prev) / prev);
        }
      });
      setPriceHistory(history);
    });

    engine.boot();

    return () => {
      unsubscribe();
      engine.shutdown();
    };
  }, []);

  const handleExport = () => {
    if (!engineRef.current) return;

    const data = engineRef.current.export();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `polyvenue-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClear = () => {
    if (confirm('Clear all market data and restart?')) {
      if (engineRef.current) {
        engineRef.current.shutdown();
        const engine = new Engine();
        engineRef.current = engine;

        const unsubscribe = engine.subscribe((newStats) => {
          setStats(newStats);
          setMarkets(engine.getMarkets());
        });

        engine.boot();
      }
    }
  };

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-slate-100 via-slate-50 to-slate-100 flex flex-col overflow-hidden">
      <Header stats={stats} isLive={stats.venues > 0} />
      <GridLayout markets={markets} priceHistory={priceHistory} />
      <Footer onExport={handleExport} onClear={handleClear} />
    </div>
  );
}
