export type VenueType = 'CB' | 'BN' | 'DY';

export interface TickData {
  sym: string;
  price: number;
  bid: number;
  ask: number;
  venue: VenueType;
  timestamp: number;
}

export interface MarketState {
  id: string;
  symbol: string;
  venue: VenueType;
  price: number;
  bid: number;
  ask: number;
  spread: number;
  volume: number;
  priceHistory: number[];
  lastUpdate: number;
  isStale: boolean;
}

export interface EngineStats {
  rx: number;
  err: number;
  venues: number;
  latency: number;
}

export interface AlphaSignal {
  code: string;
  text: string;
  timestamp: number;
}
