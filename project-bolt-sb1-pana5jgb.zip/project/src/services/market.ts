import { MarketState, TickData, VenueType } from '../types/market';
import { TUNING } from './config';

class StatWindow {
  private values: number[];
  private index: number = 0;
  private count: number = 0;
  private sum: number = 0;

  constructor(size: number) {
    this.values = new Array(size).fill(0);
  }

  push(value: number): void {
    const oldValue = this.count < this.values.length ? 0 : this.values[this.index];
    this.values[this.index] = value;
    this.sum += value - oldValue;
    this.index = (this.index + 1) % this.values.length;
    if (this.count < this.values.length) this.count++;
  }

  mean(): number {
    return this.count ? this.sum / this.count : 0;
  }
}

export class Market {
  private state: MarketState;
  private ret1s: StatWindow;
  private lastPrice: number = 0;

  constructor(id: string, symbol: string, venue: VenueType) {
    this.state = {
      id,
      symbol,
      venue,
      price: 0,
      bid: 0,
      ask: 0,
      spread: 0,
      volume: 0,
      priceHistory: [],
      lastUpdate: 0,
      isStale: true,
    };
    this.ret1s = new StatWindow(10);
  }

  update(tick: TickData): void {
    const now = Date.now();

    if (this.lastPrice > 0) {
      const r = (tick.price - this.lastPrice) / this.lastPrice;
      this.ret1s.push(Math.abs(r));
      this.state.volume = this.state.volume * TUNING.VOL_EWMA_DECAY + Math.abs(r) * (1 - TUNING.VOL_EWMA_DECAY);
    }

    this.state.price = tick.price;
    this.state.bid = tick.bid;
    this.state.ask = tick.ask;
    this.state.spread = ((tick.ask - tick.bid) / tick.price) * 10000;
    this.state.lastUpdate = now;
    this.state.isStale = false;
    this.lastPrice = tick.price;

    this.state.priceHistory.push(tick.price);
    if (this.state.priceHistory.length > TUNING.PRICE_HISTORY_SIZE) {
      this.state.priceHistory.shift();
    }
  }

  checkStale(): void {
    const now = Date.now();
    this.state.isStale = now - this.state.lastUpdate > TUNING.STALE_DATA_MS;
  }

  getState(): Readonly<MarketState> {
    return Object.freeze({ ...this.state });
  }

  getVolume(): number {
    return this.state.volume;
  }

  cleanup(): void {
    this.state.priceHistory = [];
  }
}
