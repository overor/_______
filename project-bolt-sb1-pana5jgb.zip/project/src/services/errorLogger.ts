interface ErrorEntry {
  time: number;
  context: string;
  message: string;
  stack?: string;
  data?: Record<string, unknown>;
}

export class ErrorLogger {
  private errors: ErrorEntry[] = [];
  private readonly maxErrors: number;

  constructor(maxErrors = 100) {
    this.maxErrors = maxErrors;
  }

  log(context: string, error: Error | string, data?: Record<string, unknown>): void {
    const entry: ErrorEntry = {
      time: Date.now(),
      context,
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      data,
    };

    this.errors.unshift(entry);
    if (this.errors.length > this.maxErrors) {
      this.errors.pop();
    }

    console.error(`[${context}]`, error, data);
  }

  getRecent(n = 10): ErrorEntry[] {
    return this.errors.slice(0, n);
  }

  clear(): void {
    this.errors = [];
  }
}

export const errorLogger = new ErrorLogger();
