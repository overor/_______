import { TickData } from '../types/market';
import { symbolMapper } from './symbolMapper';
import { messageValidator } from './messageValidator';

export const adapters = {
  coinbase: {
    subscribe(ws: WebSocket, markets: string[]): void {
      const msg = {
        type: 'subscribe',
        product_ids: markets,
        channels: ['ticker'],
      };
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(msg));
      }
    },

    parse(data: unknown): TickData | null {
      if (!messageValidator.coinbase(data)) return null;

      const msg = data as Record<string, unknown>;
      if (msg.type !== 'ticker') return null;

      const standardSym = symbolMapper.coinbaseToStandard(msg.product_id as string);
      if (!standardSym) return null;

      return {
        sym: standardSym,
        price: Number(msg.price),
        bid: Number(msg.best_bid),
        ask: Number(msg.best_ask),
        venue: 'CB',
        timestamp: Date.now(),
      };
    },
  },

  binance: {
    subscribe(ws: WebSocket, markets: string[]): void {
      const params = markets.map((m) => m.replace('-', '').toLowerCase() + '@bookTicker');
      const msg = { method: 'SUBSCRIBE', params, id: 1 };
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(msg));
      }
    },

    parse(data: unknown): TickData | null {
      if (!messageValidator.binance(data)) return null;

      const msg = data as Record<string, unknown>;
      const standardSym = symbolMapper.binanceToStandard(msg.s as string);
      if (!standardSym) return null;

      return {
        sym: standardSym,
        price: (Number(msg.b) + Number(msg.a)) / 2,
        bid: Number(msg.b),
        ask: Number(msg.a),
        venue: 'BN',
        timestamp: Date.now(),
      };
    },
  },

  dydx: {
    subscribe(ws: WebSocket, markets: string[]): void {
      markets.forEach((m) => {
        ws.send(JSON.stringify({ type: 'subscribe', channel: 'v4_orderbook', id: m }));
      });
    },

    parse(data: unknown): TickData | null {
      if (!messageValidator.dydx(data)) return null;

      const msg = data as Record<string, unknown>;
      const contents = msg.contents as Record<string, unknown[]>;
      const bids = contents.bids as [string, string][];
      const asks = contents.asks as [string, string][];

      if (!bids?.[0] || !asks?.[0]) return null;

      const bidPrice = Number(bids[0][0]);
      const askPrice = Number(asks[0][0]);

      return {
        sym: msg.id as string,
        price: (bidPrice + askPrice) / 2,
        bid: bidPrice,
        ask: askPrice,
        venue: 'DY',
        timestamp: Date.now(),
      };
    },
  },
};
