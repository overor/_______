const BINANCE_TO_STANDARD: Record<string, string> = {
  'BTCUSDT': 'BTC-USD',
  'ETHUSDT': 'ETH-USD',
  'SOLUSDT': 'SOL-USD',
  'DOGEUSDT': 'DOGE-USD',
  'AVAXUSDT': 'AVAX-USD',
};

const DYDX_TO_STANDARD: Record<string, string> = {
  'BTC-USD': 'BTC-USD',
  'ETH-USD': 'ETH-USD',
  'SOL-USD': 'SOL-USD',
  'DOGE-USD': 'DOGE-USD',
  'AVAX-USD': 'AVAX-USD',
};

export const symbolMapper = {
  binanceToStandard(symbol: string): string | null {
    return BINANCE_TO_STANDARD[symbol] || null;
  },

  dydxToStandard(symbol: string): string | null {
    return DYDX_TO_STANDARD[symbol] || null;
  },

  coinbaseToStandard(symbol: string): string | null {
    return symbol; // Coinbase uses standard format
  },
};
