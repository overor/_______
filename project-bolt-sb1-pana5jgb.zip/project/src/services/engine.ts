import { EngineStats, VenueType } from '../types/market';
import { Market } from './market';
import { CONFIG, TUNING } from './config';
import { adapters } from './adapters';
import { errorLogger } from './errorLogger';
import { RateLimiter } from './rateLimiter';

type Listener = (stats: EngineStats) => void;

export class Engine {
  private markets: Map<string, Market> = new Map();
  private stats: EngineStats = { rx: 0, err: 0, venues: 0, latency: 0 };
  private sockets: WebSocket[] = [];
  private dirtyMarkets: Set<string> = new Set();
  private rateLimiters: Map<string, RateLimiter> = new Map();
  private listeners: Set<Listener> = new Set();
  private lastRenderTime: number = 0;
  private isRunning: boolean = false;

  constructor() {
    CONFIG.SOURCES.forEach((src) => {
      this.rateLimiters.set(src.id, new RateLimiter(TUNING.MAX_MESSAGES_PER_SEC));
    });
  }

  boot(): void {
    if (this.isRunning) return;
    this.isRunning = true;

    CONFIG.SOURCES.forEach((src) => {
      CONFIG.MARKETS.forEach((sym) => {
        const key = `${sym}@${src.id}`;
        if (!this.markets.has(key)) {
          this.markets.set(key, new Market(key, sym, src.id as VenueType));
        }
      });
      this.connect(src);
    });

    this.renderLoop();
  }

  shutdown(): void {
    this.isRunning = false;
    this.sockets.forEach((ws) => {
      ws.close();
    });
    this.sockets = [];
    this.markets.forEach((m) => m.cleanup());
    this.markets.clear();
  }

  private connect(source: typeof CONFIG.SOURCES[0]): void {
    const adapter = adapters[source.type as keyof typeof adapters];
    if (!adapter) {
      errorLogger.log('ADAPTER', `No adapter for ${source.type}`);
      return;
    }

    console.log(`[NET] Connecting ${source.id}...`);
    const ws = new WebSocket(source.url);

    ws.onopen = () => {
      this.stats.venues++;
      adapter.subscribe(ws, CONFIG.MARKETS);
      this.notifyListeners();
    };

    ws.onmessage = (evt) => {
      const limiter = this.rateLimiters.get(source.id);
      if (limiter && !limiter.allow()) {
        this.stats.err++;
        errorLogger.log('RATE_LIMIT', `Venue ${source.id} exceeded rate limit`);
        return;
      }

      this.stats.rx++;

      try {
        const data = JSON.parse(evt.data);
        const adapter_typed = adapter as typeof adapters.coinbase;
        const tick = adapter_typed.parse(data);

        if (tick) {
          const venueMarkets = Array.from(this.markets.entries())
            .filter(([_, m]) => {
              const state = m.getState();
              return state.symbol === tick.sym && state.venue === tick.venue;
            });

          venueMarkets.forEach(([key, market]) => {
            market.update(tick);
            this.dirtyMarkets.add(key);
          });
        }
      } catch (e) {
        this.stats.err++;
        errorLogger.log('WS_PARSE', e as Error, {
          venue: source.id,
          dataPreview: evt.data.substring(0, 200),
        });
      }
    };

    ws.onerror = () => {
      this.stats.err++;
    };

    ws.onclose = () => {
      this.stats.venues--;
      this.notifyListeners();
      setTimeout(() => this.connect(source), TUNING.RECONNECT_DELAY_MS);
    };

    this.sockets.push(ws);
  }

  private renderLoop(): void {
    if (!this.isRunning) return;

    requestAnimationFrame(() => this.renderLoop());

    const now = Date.now();
    if (now - this.lastRenderTime < TUNING.RENDER_THROTTLE_MS) return;

    this.lastRenderTime = now;

    this.markets.forEach((m) => m.checkStale());
    this.dirtyMarkets.clear();
    this.notifyListeners();
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => {
      listener(this.stats);
    });
  }

  getStats(): Readonly<EngineStats> {
    return Object.freeze({ ...this.stats });
  }

  getMarkets(): ReadonlyMap<string, Market> {
    return new Map(this.markets);
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  export(): Record<string, unknown> {
    return {
      timestamp: Date.now(),
      stats: this.stats,
      markets: Array.from(this.markets.entries()).map(([k, m]) => ({
        key: k,
        ...m.getState(),
      })),
      errors: errorLogger.getRecent(50),
    };
  }
}
