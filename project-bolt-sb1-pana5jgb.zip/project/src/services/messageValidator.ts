export const messageValidator = {
  coinbase(data: unknown): boolean {
    if (!data || typeof data !== 'object') return false;
    const msg = data as Record<string, unknown>;
    return (
      typeof msg.type === 'string' &&
      typeof msg.product_id === 'string' &&
      !isNaN(Number(msg.price))
    );
  },

  binance(data: unknown): boolean {
    if (!data || typeof data !== 'object') return false;
    const msg = data as Record<string, unknown>;
    return (
      typeof msg.s === 'string' &&
      !isNaN(Number(msg.b)) &&
      !isNaN(Number(msg.a))
    );
  },

  dydx(data: unknown): boolean {
    if (!data || typeof data !== 'object') return false;
    const msg = data as Record<string, unknown>;
    const contents = msg.contents as Record<string, unknown>;
    return (
      typeof msg.channel === 'string' &&
      msg.channel === 'v4_orderbook' &&
      contents &&
      Array.isArray(contents.bids) &&
      Array.isArray(contents.asks)
    );
  },
};
