export interface SourceConfig {
  id: string;
  url: string;
  type: 'coinbase' | 'binance' | 'dydx';
}

export const CONFIG = {
  SOURCES: [
    {
      id: 'CB',
      url: import.meta.env.VITE_COINBASE_WS || 'wss://ws-feed.exchange.coinbase.com',
      type: 'coinbase' as const,
    },
    {
      id: 'BN',
      url: import.meta.env.VITE_BINANCE_WS || 'wss://stream.binance.com:9443/ws',
      type: 'binance' as const,
    },
    {
      id: 'DY',
      url: import.meta.env.VITE_DYDX_WS || 'wss://indexer.dydx.trade/v4/ws',
      type: 'dydx' as const,
    },
  ],
  MARKETS: ['BTC-USD', 'ETH-USD', 'SOL-USD', 'DOGE-USD', 'AVAX-USD'],
};

export const TUNING = {
  VOL_EWMA_DECAY: 0.9,
  SPREAD_THRESHOLD_BPS: 1.0,
  VOL_THRESHOLD: 0.0005,
  RECONNECT_DELAY_MS: 5000,
  STALE_DATA_MS: 2000,
  RENDER_THROTTLE_MS: 50,
  MAX_MESSAGES_PER_SEC: 1000,
  PRICE_HISTORY_SIZE: 50,
};
