export class RateLimiter {
  private count: number = 0;
  private resetTime: number = Date.now() + 1000;
  private readonly maxPerSecond: number;

  constructor(maxPerSecond: number) {
    this.maxPerSecond = maxPerSecond;
  }

  allow(): boolean {
    const now = Date.now();

    if (now > this.resetTime) {
      this.count = 0;
      this.resetTime = now + 1000;
    }

    if (this.count >= this.maxPerSecond) {
      return false;
    }

    this.count++;
    return true;
  }

  reset(): void {
    this.count = 0;
    this.resetTime = Date.now() + 1000;
  }
}
