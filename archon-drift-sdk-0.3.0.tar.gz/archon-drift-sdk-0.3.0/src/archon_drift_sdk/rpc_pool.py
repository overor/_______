from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable, List, Optional, TypeVar

from .exceptions import RpcError

T = TypeVar("T")


@dataclass
class RpcEndpointState:
    url: str
    ewma_latency_ms: float = 500.0
    consecutive_failures: int = 0
    last_failure_ts: float = 0.0
    in_flight: int = 0
    semaphore: asyncio.Semaphore = field(default_factory=lambda: asyncio.Semaphore(8))


class RpcPool:
    """Rate-limit aware RPC selection + failover with bounded concurrency."""

    def __init__(
        self,
        urls: List[str],
        *,
        max_retries: int = 3,
        base_retry_delay_ms: int = 250,
        failure_cooldown_s: int = 10,
        per_endpoint_concurrency: int = 8,
    ):
        if not urls:
            raise ValueError("RpcPool requires >=1 URL")
        self._eps: List[RpcEndpointState] = [
            RpcEndpointState(url=u, semaphore=asyncio.Semaphore(per_endpoint_concurrency))
            for u in urls
        ]
        self._max_retries = max_retries
        self._base_retry_delay_ms = base_retry_delay_ms
        self._failure_cooldown_s = failure_cooldown_s

    def _score(self, ep: RpcEndpointState) -> float:
        cooldown_penalty = 0.0
        if ep.consecutive_failures > 0:
            age = time.time() - ep.last_failure_ts
            if age < self._failure_cooldown_s:
                cooldown_penalty = 10_000.0
        failure_penalty = ep.consecutive_failures * 1_000.0
        inflight_penalty = ep.in_flight * 50.0
        return ep.ewma_latency_ms + failure_penalty + inflight_penalty + cooldown_penalty

    def pick(self) -> RpcEndpointState:
        return min(self._eps, key=self._score)

    async def call(self, fn_factory: Callable[[str], Awaitable[T]]) -> T:
        last_exc: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            ep = self.pick()
            async with ep.semaphore:
                ep.in_flight += 1
                t0 = time.perf_counter()
                try:
                    res = await fn_factory(ep.url)
                    dt = (time.perf_counter() - t0) * 1000.0
                    ep.ewma_latency_ms = 0.8 * ep.ewma_latency_ms + 0.2 * dt
                    ep.consecutive_failures = 0
                    return res
                except Exception as e:
                    last_exc = e
                    ep.consecutive_failures += 1
                    ep.last_failure_ts = time.time()
                finally:
                    ep.in_flight = max(0, ep.in_flight - 1)

            if attempt < self._max_retries:
                backoff = self._base_retry_delay_ms * (2 ** attempt)
                jitter = random.randint(0, 100)
                await asyncio.sleep((backoff + jitter) / 1000.0)

        raise RpcError(str(last_exc)) from last_exc
