from __future__ import annotations

import asyncio
import base64
import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Set, Tuple

import websockets

from .exceptions import WsError


def rpc_http_to_ws(rpc_url: str) -> str:
    # https://api.mainnet-beta.solana.com -> wss://api.mainnet-beta.solana.com/
    u = rpc_url.strip()
    u = re.sub(r"^http://", "ws://", u)
    u = re.sub(r"^https://", "wss://", u)
    if not u.endswith("/"):
        u += "/"
    return u


@dataclass
class AccountUpdate:
    pubkey: str
    slot: int
    lamports: int
    owner: str
    executable: bool
    rent_epoch: int
    data: bytes


@dataclass
class WsCache:
    """State cache updated by websocket notifications."""

    accounts: Dict[str, AccountUpdate] = field(default_factory=dict)
    dirty_accounts: Set[str] = field(default_factory=set)

    # for 'oracle' we only set dirty and let app decode via its canonical source (Drift/Pyth)
    dirty_oracles: Set[str] = field(default_factory=set)

    last_slot: int = 0
    last_update_ts: float = 0.0

    def mark_oracle(self, pubkey: str) -> None:
        self.dirty_oracles.add(pubkey)

    def set_account(self, upd: AccountUpdate) -> None:
        self.accounts[upd.pubkey] = upd
        self.dirty_accounts.add(upd.pubkey)
        self.last_slot = max(self.last_slot, upd.slot)
        self.last_update_ts = time.time()

    def clear_dirty(self) -> Tuple[Set[str], Set[str]]:
        a = set(self.dirty_accounts)
        o = set(self.dirty_oracles)
        self.dirty_accounts.clear()
        self.dirty_oracles.clear()
        return a, o


class SolanaWsSubscriber:
    """
    Solana JSON-RPC websocket subscriber for account notifications.
    Designed to be wired into a trading loop via WsCache + an asyncio.Event.
    """

    def __init__(self, rpc_http_url: str, *, commitment: str = "processed"):
        self.ws_url = rpc_http_to_ws(rpc_http_url)
        self.commitment = commitment

        self.cache = WsCache()
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._task: Optional[asyncio.Task] = None

        self._next_id = 1
        self._sub_to_pubkey: Dict[int, str] = {}
        self._pubkey_kind: Dict[str, str] = {}  # pubkey -> "account" | "oracle"

        self.updated = asyncio.Event()
        self._stop = asyncio.Event()

    async def connect(self) -> None:
        try:
            self._ws = await websockets.connect(self.ws_url, ping_interval=20, ping_timeout=20)
        except Exception as e:
            raise WsError(f"ws connect failed: {e}") from e

    async def close(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except Exception:
                pass
        if self._ws:
            await self._ws.close()

    async def subscribe_account(self, pubkey: str, *, kind: str = "account") -> int:
        if not self._ws:
            raise WsError("not connected")

        req_id = self._next_id
        self._next_id += 1

        self._pubkey_kind[pubkey] = kind

        msg = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": "accountSubscribe",
            "params": [
                pubkey,
                {
                    "encoding": "base64",
                    "commitment": self.commitment,
                },
            ],
        }
        await self._ws.send(json.dumps(msg))
        resp = json.loads(await self._ws.recv())
        if "error" in resp:
            raise WsError(f"subscribe error: {resp['error']}")
        sub_id = int(resp["result"])
        self._sub_to_pubkey[sub_id] = pubkey
        return sub_id

    async def start(self) -> None:
        if not self._ws:
            raise WsError("not connected")
        if self._task:
            return
        self._task = asyncio.create_task(self._run())

    async def _run(self) -> None:
        assert self._ws is not None
        while not self._stop.is_set():
            try:
                raw = await self._ws.recv()
                msg = json.loads(raw)
            except asyncio.CancelledError:
                return
            except Exception:
                continue

            # accountNotification
            if msg.get("method") != "accountNotification":
                continue

            params = msg.get("params", {})
            sub = int(params.get("subscription", 0))
            pubkey = self._sub_to_pubkey.get(sub)
            if not pubkey:
                continue

            result = params.get("result", {})
            ctx = result.get("context", {})
            slot = int(ctx.get("slot", 0))
            val = result.get("value", {})

            data_field = val.get("data", ["", "base64"])
            b64 = data_field[0] if isinstance(data_field, list) and data_field else ""
            try:
                data = base64.b64decode(b64) if b64 else b""
            except Exception:
                data = b""

            upd = AccountUpdate(
                pubkey=pubkey,
                slot=slot,
                lamports=int(val.get("lamports", 0)),
                owner=str(val.get("owner", "")),
                executable=bool(val.get("executable", False)),
                rent_epoch=int(val.get("rentEpoch", 0)),
                data=data,
            )

            kind = self._pubkey_kind.get(pubkey, "account")
            if kind == "oracle":
                self.cache.mark_oracle(pubkey)
            else:
                self.cache.set_account(upd)

            self.updated.set()
