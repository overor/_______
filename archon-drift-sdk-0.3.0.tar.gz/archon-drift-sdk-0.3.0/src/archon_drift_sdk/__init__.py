"""archon_drift_sdk

Pip-installable building blocks for public-RPC-first Solana/Drift bots:
- Public API manifest ingestion (Pydantic)
- RPC pool (rate-limit aware, bounded concurrency, failover)
- Direct on-chain Drift execution helper (driftpy)
- Solana WebSocket subscriptions (account/oracle) with state cache + dirty flags
- Optional LLM clients (HF router included; KaggleHub left to your app layer)
"""

from .manifest import PublicAPIManifest
from .rpc_pool import RpcPool
from .drift_execution import DriftExecution, DriftEnvConfig
from .ws_subscriber import SolanaWsSubscriber, AccountUpdate, WsCache
from .hf_llm_client import HFRouterChat, HFRouterConfig

__all__ = [
    "PublicAPIManifest",
    "RpcPool",
    "DriftExecution",
    "DriftEnvConfig",
    "SolanaWsSubscriber",
    "AccountUpdate",
    "WsCache",
    "HFRouterChat",
    "HFRouterConfig",
]
