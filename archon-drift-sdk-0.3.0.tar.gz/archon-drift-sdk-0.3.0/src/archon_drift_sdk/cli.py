from __future__ import annotations

import argparse
import asyncio
import json

from .manifest import PublicAPIManifest
from .ws_subscriber import SolanaWsSubscriber


def _load_manifest(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


async def _cmd_ws_watch(args: argparse.Namespace) -> int:
    m = PublicAPIManifest.load(_load_manifest(args.manifest))
    sol = str(m.endpoints.blockchain["solana"].url)

    ws = SolanaWsSubscriber(sol, commitment=args.commitment)
    await ws.connect()

    for pk in args.account_pubkeys:
        await ws.subscribe_account(pk, kind="account")
    for pk in args.oracle_pubkeys:
        await ws.subscribe_account(pk, kind="oracle")

    await ws.start()

    print(json.dumps({"ok": True, "ws_url": ws.ws_url}, indent=2))
    try:
        while True:
            await asyncio.wait_for(ws.updated.wait(), timeout=60)
            ws.updated.clear()
            dirty_accounts, dirty_oracles = ws.cache.clear_dirty()
            print(json.dumps({"dirty_accounts": list(dirty_accounts), "dirty_oracles": list(dirty_oracles), "slot": ws.cache.last_slot}))
    finally:
        await ws.close()


def main() -> None:
    p = argparse.ArgumentParser(prog="archon-drift-sdk", description="archon_drift_sdk CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    w = sub.add_parser("ws-watch", help="Watch account/oracle pubkeys via Solana WebSocket")
    w.add_argument("--manifest", required=True, help="Path to public-api-config JSON")
    w.add_argument("--commitment", default="processed", choices=["processed", "confirmed", "finalized"])
    w.add_argument("--account-pubkeys", nargs="*", default=[])
    w.add_argument("--oracle-pubkeys", nargs="*", default=[])

    args = p.parse_args()
    if args.cmd == "ws-watch":
        raise SystemExit(asyncio.run(_cmd_ws_watch(args)))


if __name__ == "__main__":
    main()
