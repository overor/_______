from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, Optional, Sequence

from anchorpy import Wallet
from solders.keypair import Keypair
from solana.rpc.async_api import AsyncClient

from .exceptions import DriftError

try:
    from driftpy.drift_client import DriftClient
    from driftpy.types import OrderParams, OrderType, PositionDirection
except Exception as e:  # pragma: no cover
    DriftClient = None
    OrderParams = None
    OrderType = None
    PositionDirection = None
    _import_error = e


def _load_solana_keypair(env_var: str) -> Keypair:
    raw = os.getenv(env_var)
    if not raw:
        raise DriftError(f"{env_var} not set")

    s = raw.strip()
    if s.startswith("["):
        arr = json.loads(s)
        if not isinstance(arr, list) or len(arr) != 64:
            raise DriftError(f"{env_var} JSON must be a 64-byte array")
        return Keypair.from_bytes(bytes(arr))
    return Keypair.from_base58_string(s)


@dataclass
class DriftEnvConfig:
    rpc_url: str
    drift_env: str = "mainnet"  # "mainnet" | "devnet"
    sub_account_id: int = 0
    perp_market_indexes: Optional[Sequence[int]] = None
    spot_market_indexes: Optional[Sequence[int]] = None


class DriftExecution:
    """Direct on-chain Drift execution client (no gateway)."""

    def __init__(self, cfg: DriftEnvConfig, keypair_env: str = "SOLANA_PRIVATE_KEY"):
        if DriftClient is None:  # pragma: no cover
            raise DriftError(f"driftpy import failed: {_import_error}")
        self.cfg = cfg
        self.keypair = _load_solana_keypair(keypair_env)
        self.wallet = Wallet(self.keypair)
        self._client: Optional[AsyncClient] = None
        self._drift: Optional[DriftClient] = None

    @property
    def drift(self) -> DriftClient:
        if not self._drift:
            raise DriftError("DriftExecution not initialized")
        return self._drift

    @property
    def client(self) -> AsyncClient:
        if not self._client:
            raise DriftError("DriftExecution not initialized")
        return self._client

    async def initialize(self) -> None:
        self._client = AsyncClient(self.cfg.rpc_url)
        self._drift = DriftClient(
            self._client,
            self.wallet,
            self.cfg.drift_env,
            perp_market_indexes=list(self.cfg.perp_market_indexes or []),
            spot_market_indexes=list(self.cfg.spot_market_indexes or []),
        )

        await self._drift.add_user(self.cfg.sub_account_id)
        await self._drift.subscribe()

    async def close(self) -> None:
        if self._drift:
            try:
                await self._drift.unsubscribe()
            except Exception:
                pass
        if self._client:
            await self._client.close()

    async def place_market_perp(
        self,
        *,
        market_index: int,
        direction: str,          # "LONG" | "SHORT"
        base_size: float,        # base units (e.g., SOL)
        reduce_only: bool = False,
    ) -> str:
        if direction not in ("LONG", "SHORT"):
            raise DriftError("direction must be LONG|SHORT")

        dir_obj = PositionDirection.Long() if direction == "LONG" else PositionDirection.Short()

        order = OrderParams(
            order_type=OrderType.Market(),
            direction=dir_obj,
            base_asset_amount=int(base_size * 1e9),
            market_index=market_index,
            reduce_only=reduce_only,
        )

        try:
            sig = await self.drift.place_perp_order(order)
            return str(sig)
        except Exception as e:
            raise DriftError(str(e)) from e

    def get_open_perp_positions(self) -> Dict[int, object]:
        user = self.drift.get_user()
        out: Dict[int, object] = {}
        for p in user.get_perp_positions():
            if getattr(p, "base_asset_amount", 0) != 0:
                out[getattr(p, "market_index")] = p
        return out
