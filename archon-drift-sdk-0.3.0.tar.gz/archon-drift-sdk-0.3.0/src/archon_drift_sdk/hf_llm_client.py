from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import aiohttp


@dataclass
class HFRouterConfig:
    base_url: str = "https://router.huggingface.co/v1/chat/completions"
    token_env: str = "HF_TOKEN"
    model: str = "meta-llama/Meta-Llama-3-70B-Instruct"
    timeout_s: int = 30
    temperature: float = 0.2
    max_tokens: int = 500


class HFRouterChat:
    """OpenAI-compatible chat client targeting HF router."""

    def __init__(self, cfg: HFRouterConfig):
        tok = os.getenv(cfg.token_env)
        if not tok:
            raise ValueError(f"{cfg.token_env} not set")
        self.cfg = cfg
        self.token = tok
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.cfg.timeout_s)
        )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self._session:
            await self._session.close()

    async def chat(self, messages: List[Dict[str, str]]) -> str:
        assert self._session is not None

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        payload: Dict[str, Any] = {
            "model": self.cfg.model,
            "messages": messages,
            "temperature": self.cfg.temperature,
            "max_tokens": self.cfg.max_tokens,
        }

        async with self._session.post(self.cfg.base_url, headers=headers, json=payload) as r:
            data = await r.json()
            return data["choices"][0]["message"]["content"]
