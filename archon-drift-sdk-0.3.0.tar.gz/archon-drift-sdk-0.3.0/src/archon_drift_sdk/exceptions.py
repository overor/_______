class ArchonSDKError(Exception):
    """Base error for archon_drift_sdk."""


class ManifestError(ArchonSDKError):
    """Manifest validation/load error."""


class RpcError(ArchonSDKError):
    """RPC pool failure."""


class DriftError(ArchonSDKError):
    """Drift execution failure."""


class WsError(ArchonSDKError):
    """WebSocket subscription failure."""
