# archon-drift-sdk

Adds websocket subscriptions (account/oracle) suitable for wiring into a trading loop.

## Install

```bash
pip install archon-drift-sdk
```

## Websocket subscription wiring (pattern)

You create the subscriber once at startup, subscribe to:
- Drift user account pubkey (kind="account")
- each oracle pubkey (kind="oracle")

Then your `trading_cycle()` consumes *dirty flags* and refreshes canonical state via Drift/pyth.

### Example integration (pseudo, drop into your orchestrator)

```python
from archon_drift_sdk.ws_subscriber import SolanaWsSubscriber

class DegenArchon:
    async def initialize(self):
        self.ws = SolanaWsSubscriber(self.config.rpc_url, commitment="processed")
        await self.ws.connect()

        # 1) Subscribe to your Drift user account
        user_pubkey = await self.trader.get_user_account_pubkey()  # implement via driftpy/user PDA derivation
        await self.ws.subscribe_account(user_pubkey, kind="account")

        # 2) Subscribe to oracle accounts (pubkeys from perp market accounts)
        for oracle_pk in await self.trader.get_oracle_pubkeys():
            await self.ws.subscribe_account(str(oracle_pk), kind="oracle")

        await self.ws.start()

    async def trading_cycle(self):
        # wait for at least one update, or run on a cadence
        try:
            await asyncio.wait_for(self.ws.updated.wait(), timeout=1.0)
        except asyncio.TimeoutError:
            pass
        self.ws.updated.clear()

        dirty_accounts, dirty_oracles = self.ws.cache.clear_dirty()

        # if user account updated => refresh positions/margin once
        if dirty_accounts:
            await self.trader.refresh_user_state()

        # if any oracle updated => refresh prices once (canonical decode via Drift/Pyth)
        if dirty_oracles:
            await self.trader.refresh_oracle_state()

        # now execute your normal logic using refreshed state
        return await self._run_signals_and_execution()
```

## CLI

```bash
archon-drift-sdk ws-watch --manifest ./public-api-config.json --account-pubkeys <PK> --oracle-pubkeys <PK>
```
