from archon_drift_sdk.ws_subscriber import rpc_http_to_ws

def test_rpc_http_to_ws():
    assert rpc_http_to_ws("https://api.mainnet-beta.solana.com") == "wss://api.mainnet-beta.solana.com/"
    assert rpc_http_to_ws("http://localhost:8899") == "ws://localhost:8899/"
